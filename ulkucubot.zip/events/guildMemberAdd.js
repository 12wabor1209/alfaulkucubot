module.exports = member => {
    let username = member.user.username;
    member.sendMessage('Hoşgeldin **' + username + '**, Aramıza yeni bir alfa adayı katıldı! :lukaa:');

};
